package com.michelle.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.michelle.model.Order;

@Repository
@Transactional
public interface OrderRepository extends JpaRepository<Order, Long> {

	Order findById(long id);
}
