package com.michelle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SpringBootDBProductsApplication {

    public static void main(String[] args) {
    	SpringApplication.run(SpringBootDBProductsApplication.class, args);
    }

}
