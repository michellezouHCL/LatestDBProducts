package com.michelle.exception;

public class ProdNotFoundException extends Exception{

	public ProdNotFoundException(String s) {
		super(s);
	}
}
