package com.michelle.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter 
@Setter
@NoArgsConstructor
@Entity
@Table(name="role")
public class Role {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "role_id")
	private long roleId;
	@Column(name = "role_name", nullable = false)
	private String roleName;

	
	public Role(long roleId, String role) {
		this.roleId=roleId;
		this.roleName = role;
	}

	public Role(String string) {
		this.roleName=string;
	}

	@Override
	public String toString() {
		return this.roleName;
	}
}


