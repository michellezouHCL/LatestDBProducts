package com.michelle.model;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@NoArgsConstructor
public class Cart {

	private long itemId;
	private String itemName;
	private float price;
	private int quantity;
	private String category;
	private byte[] photos;
	private int instockQty;
	private float total;
	
	public Cart(long itemId, String itemName, float price, int quantity, String category, byte[] photos, int instockQty) {
		this.itemId = itemId;
		this.itemName = itemName;
		this.price = price;
		this.quantity = quantity;
		this.category=category;
		this.photos=photos;
		this.instockQty=instockQty;
		this.total =quantity*price;
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return this.getItemId() == ((Cart) obj).getItemId();
	}

	public void ToCart(Product p) {
		this.itemId = p.getProductId();
		this.itemName = p.getProductName();
		this.category=p.getCategory().getCategoryName();
		this.photos=p.getPhotos();
		this.price = p.getProductPrice();
		this.instockQty=p.getInstockQty();
		if(this.quantity!=0) {
			this.quantity+=1;
		}
		else {
			this.quantity=1;
		}
		this.total=this.price*this.quantity;
	}
	/*
	 * public Product findProdInCartById(long id) { for (Product prod :
	 * this.getProdList()) { if (prod.getProductId()==id) { return prod; } } return
	 * null; }
	 * 
	 * public void addToCart(Product product) { Product p =
	 * this.findProdInCartById(product.getProductId()); if(p==null) { p = new
	 * Product(); p.setProductId(product.getProductId());
	 * p.setProductName(product.getProductName());
	 * p.setInstockQty(product.getInstockQty());
	 * p.setProductPrice(product.getProductPrice()); p.setProductQty(1);
	 * this.prodList.add(p);
	 * p.setProductTotal(p.getProductQty()*p.getProductPrice()); } else { if
	 * (p.getInstockQty() > p.getProductQty() && p.getProductQty() > -1)
	 * p.setProductQty(p.getProductQty() + 1);
	 * p.setProductTotal(p.getProductQty()*p.getProductPrice()); } }
	 * 
	 * public Product addOne(Long id) { Product p1 = this.findProdInCartById(id); if
	 * (p1.getInstockQty() > p1.getProductQty() && p1.getProductQty() > -1)
	 * p1.setProductQty(p1.getProductQty() + 1);
	 * p1.setProductTotal(p1.getProductPrice() * p1.getProductQty()); return p1; }
	 * 
	 * public Product minusOne(Long id) { Product p1 = this.findProdInCartById(id);
	 * if (p1.getInstockQty() >= p1.getProductQty() && p1.getProductQty() > 0)
	 * p1.setProductQty(p1.getProductQty() - 1);
	 * p1.setProductTotal(p1.getProductPrice() * p1.getProductQty()); return p1; }
	 * 
	 * public Product clearCart(long id) { Product p1 = this.findProdInCartById(id);
	 * p1.setProductQty(0); p1.setProductTotal(0); return p1; }
	 * 
	 * public void deleteProd (long id) { Product p1=this.findProdInCartById(id);
	 * this.prodList.remove(p1); }
	 * 
	 * public boolean isEmpty() { return this.prodList.isEmpty(); }
	 */
}
