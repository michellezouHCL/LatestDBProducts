package com.michelle.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.michelle.exception.ProdNotFoundException;
import com.michelle.model.Order;
import com.michelle.model.Product;
import com.michelle.repo.OrderRepository;
import com.michelle.repo.ProductRepository;

@Service
public class OrderService {
	@Autowired
	OrderRepository or;

	public void save(Order orderProdList) {
		or.save(orderProdList);
	}

	public List<Order> getAll() {
		return or.findAll();
	}

	public void deleteOrder(long id) {
		or.deleteById(id);
	}

	public Order findById(long id) {
		return or.findById(id);
	}

	public void delete(Order orderProdLists) {
		or.delete(orderProdLists);
	}
}
