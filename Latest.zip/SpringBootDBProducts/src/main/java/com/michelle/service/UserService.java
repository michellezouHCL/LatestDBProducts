package com.michelle.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.michelle.model.Role;
import com.michelle.model.User;
import com.michelle.repo.RoleRepository;
import com.michelle.repo.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository ur;

	@Autowired RoleRepository roleRepo;
	
	public void saveUserWithDefaultRole(User user) {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword = passwordEncoder.encode(user.getPassword());
		user.setPassword(encodedPassword);

		Role roleUser=roleRepo.findByName("User");
		user.addRole(roleUser);
		ur.save(user);
	}
}
