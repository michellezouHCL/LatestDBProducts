insert into users(username,password,role,enabled) values('saran','$2y$12$ddDgUuhOBqQm1ELfMLDd4.L6iyBE1uWHUZ.0t7Hw2lftCfGxZAMYm', 'ROLE_USER', true);
insert into users(username,password,role,enabled) values('admin','$2y$12$/EbcmLiR8ig6V/Z1C2JqQer3KmUIXpDHDCMwPKtWyNyhrOKB/NFxG', 'ROLE_ADMIN', true);

INSERT INTO `bootdb`.`category` (`category_name`) VALUES ('Food');
INSERT INTO `bootdb`.`category` (`category_name`) VALUES ('Electronics');